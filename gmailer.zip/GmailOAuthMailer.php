<?php
require 'vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\OAuth;
use PHPMailer\PHPMailer\Exception;
use League\OAuth2\Client\Provider\Google;

class GmailOAuthMailer {
    private $mail;
    private $config;

    public function __construct($config) {
        $this->config = $config;
        $this->initializeMailer();
    }

    private function initializeMailer() {
        $this->mail = new PHPMailer(true);
        
        // Server settings
        $this->mail->isSMTP();
        $this->mail->Host       = 'smtp.gmail.com';
        $this->mail->SMTPAuth   = true;
        $this->mail->AuthType   = 'XOAUTH2';
        $this->mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $this->mail->Port       = 587;
        $this->mail->SMTPDebug  = 2; // Enable debugging
        $this->mail->Debugoutput = function($str, $level) {
            error_log("SMTP debug level $level: $str");
        };
        
        // Disable authentication that might interfere with OAuth
        $this->mail->SMTPAutoTLS = false;
        
        // Set OAuth2 provider
        $provider = new Google([
            'clientId'     => $this->config['client_id'],
            'clientSecret' => $this->config['client_secret'],
        ]);
        
        // Set OAuth2 token - CRITICAL: Make sure all parameters are correct
        $this->mail->setOAuth(
            new OAuth([
                'provider'     => $provider,
                'clientId'     => $this->config['client_id'],
                'clientSecret' => $this->config['client_secret'],
                'refreshToken' => $this->config['refresh_token'],
                'userName'     => $this->config['email'],
            ])
        );
        
        // Character set
        $this->mail->CharSet = 'UTF-8';
        
        // From email and name - MUST match the OAuth authorized email
        $this->mail->setFrom($this->config['email'], $this->config['from_name']);
        
        // Important: Clear any default authentication
        $this->mail->Username = '';
        $this->mail->Password = '';
    }

    public function sendEmail($to, $subject, $body, $isHTML = true) {
        try {
            // Clear previous recipients
            $this->mail->clearAddresses();
            $this->mail->clearReplyTos();
            
            // Recipients
            if (is_array($to)) {
                foreach ($to as $email => $name) {
                    $this->mail->addAddress($email, $name);
                }
            } else {
                $this->mail->addAddress($to);
            }

            // Content
            $this->mail->isHTML($isHTML);
            $this->mail->Subject = $subject;
            $this->mail->Body    = $body;
            
            if (!$isHTML) {
                $this->mail->AltBody = strip_tags($body);
            }

            $this->mail->send();
            return [
                'success' => true, 
                'message' => 'Email sent successfully!'
            ];
            
        } catch (Exception $e) {
            $error = $this->mail->ErrorInfo;
            error_log('Mailer Error: ' . $error);
            return [
                'success' => false, 
                'message' => 'Sorry, we encountered an error sending your message. Please try again later.',
                'error' => $error
            ];
        }
    }
}
?>