<?php
// Debug the mailer specifically
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

echo "<pre>";
echo "=== Gmail Mailer Debug ===\n\n";

// Check if config exists
if (!file_exists('config.php')) {
    die("❌ config.php not found");
}
if (!file_exists('GmailOAuthMailer.php')) {
    die("❌ GmailOAuthMailer.php not found");
}

require_once 'config.php';
require_once 'GmailOAuthMailer.php';

echo "✅ Config files loaded\n";

// Check if constants are defined
if (!defined('GMAIL_OAUTH_CONFIG')) {
    die("❌ GMAIL_OAUTH_CONFIG constant not defined");
}

echo "✅ GMAIL_OAUTH_CONFIG defined\n";
print_r(GMAIL_OAUTH_CONFIG);

echo "\n=== Testing Mailer Initialization ===\n";

try {
    $mailer = new GmailOAuthMailer(GMAIL_OAUTH_CONFIG);
    echo "✅ Mailer initialized successfully\n";
    
    // Test sending a simple email
    echo "\n=== Testing Email Send ===\n";
    $result = $mailer->sendEmail(
        'yboian577@gmail.com', // Send to yourself
        'Test Email from Debug',
        '<h1>Test Email</h1><p>This is a test email from the debug script.</p>',
        true
    );
    
    echo "Send result:\n";
    print_r($result);
    
    if ($result['success']) {
        echo "✅ Email sent successfully!\n";
    } else {
        echo "❌ Email failed to send\n";
        if (isset($result['error'])) {
            echo "Error details: " . $result['error'] . "\n";
        }
    }
    
} catch (Exception $e) {
    echo "❌ Error initializing mailer: " . $e->getMessage() . "\n";
    echo "Stack trace:\n" . $e->getTraceAsString() . "\n";
}

echo "</pre>";
?>