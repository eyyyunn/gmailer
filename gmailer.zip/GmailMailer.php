<?php
require 'vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

class GmailMailer {
    private $mail;
    private $config;

    public function __construct($config) {
        $this->config = $config;
        $this->initializeMailer();
    }

    private function initializeMailer() {
        $this->mail = new PHPMailer(true);
        
        // Server settings
        $this->mail->isSMTP();
        $this->mail->Host       = 'smtp.gmail.com';
        $this->mail->SMTPAuth   = true;
        $this->mail->Username   = $this->config['username'];
        $this->mail->Password   = $this->config['password'];
        $this->mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $this->mail->Port       = 587;
        
        // Character set
        $this->mail->CharSet = 'UTF-8';
        
        // From email and name
        $this->mail->setFrom($this->config['username'], $this->config['from_name']);
    }

    public function sendEmail($to, $subject, $body, $isHTML = true, $attachments = []) {
        try {
            // Recipients
            if (is_array($to)) {
                foreach ($to as $email => $name) {
                    if (is_int($email)) {
                        $this->mail->addAddress($name);
                    } else {
                        $this->mail->addAddress($email, $name);
                    }
                }
            } else {
                $this->mail->addAddress($to);
            }

            // Attachments
            foreach ($attachments as $attachment) {
                $this->mail->addAttachment($attachment['path'], $attachment['name']);
            }

            // Content
            $this->mail->isHTML($isHTML);
            $this->mail->Subject = $subject;
            $this->mail->Body    = $body;
            
            if (!$isHTML) {
                $this->mail->AltBody = strip_tags($body);
            }

            $this->mail->send();
            return ['success' => true, 'message' => 'Message has been sent'];
            
        } catch (Exception $e) {
            return [
                'success' => false, 
                'message' => "Message could not be sent. Mailer Error: {$this->mail->ErrorInfo}"
            ];
        }
    }

    public function addCC($email, $name = '') {
        $this->mail->addCC($email, $name);
    }

    public function addBCC($email, $name = '') {
        $this->mail->addBCC($email, $name);
    }

    public function addReplyTo($email, $name = '') {
        $this->mail->addReplyTo($email, $name);
    }
}
?>