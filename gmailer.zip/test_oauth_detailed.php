<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

echo "<pre>";
echo "=== Detailed OAuth Test ===\n\n";

require_once 'config.php';
require_once 'vendor/autoload.php';

use League\OAuth2\Client\Provider\Google;
use League\OAuth2\Client\Provider\Exception\IdentityProviderException;

$config = GMAIL_OAUTH_CONFIG;

echo "Testing OAuth Configuration:\n";
echo "Email: " . $config['email'] . "\n";
echo "Client ID: " . $config['client_id'] . "\n";
echo "Client Secret: " . $config['client_secret'] . "\n";
echo "Refresh Token: " . substr($config['refresh_token'], 0, 20) . "...\n\n";

// Test the OAuth provider
try {
    $provider = new Google([
        'clientId'     => $config['client_id'],
        'clientSecret' => $config['client_secret'],
    ]);
    
    echo "✅ OAuth Provider initialized successfully\n";
    
    // Try to get a new access token using the refresh token
    echo "\nTesting Refresh Token:\n";
    
    $newToken = $provider->getAccessToken('refresh_token', [
        'refresh_token' => $config['refresh_token']
    ]);
    
    echo "✅ Refresh token works!\n";
    echo "New Access Token: " . substr($newToken->getToken(), 0, 20) . "...\n";
    echo "Expires: " . date('Y-m-d H:i:s', $newToken->getExpires()) . "\n";
    
} catch (IdentityProviderException $e) {
    echo "❌ OAuth Error: " . $e->getMessage() . "\n";
    echo "Response: " . $e->getResponseBody() . "\n";
    
} catch (Exception $e) {
    echo "❌ General Error: " . $e->getMessage() . "\n";
}

echo "\n=== Testing PHPMailer OAuth ===\n";

try {
    $mail = new PHPMailer\PHPMailer\PHPMailer(true);
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->AuthType = 'XOAUTH2';
    $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;
    
    $provider = new Google([
        'clientId'     => $config['client_id'],
        'clientSecret' => $config['client_secret'],
    ]);
    
    $mail->setOAuth(
        new PHPMailer\PHPMailer\OAuth([
            'provider'     => $provider,
            'clientId'     => $config['client_id'],
            'clientSecret' => $config['client_secret'],
            'refreshToken' => $config['refresh_token'],
            'userName'     => $config['email'],
        ])
    );
    
    echo "✅ PHPMailer OAuth configured successfully\n";
    
} catch (Exception $e) {
    echo "❌ PHPMailer OAuth Error: " . $e->getMessage() . "\n";
}

echo "</pre>";
?>