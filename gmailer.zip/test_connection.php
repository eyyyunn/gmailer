<?php
header('Content-Type: application/json');
echo json_encode([
    'success' => true,
    'message' => 'Server connection successful!',
    'timestamp' => date('Y-m-d H:i:s')
]);
?>