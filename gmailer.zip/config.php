<?php
// OAuth2 Configuration for Gmail
define('GMAIL_OAUTH_CONFIG', [
    'email'         => 'yboian577@gmail.com', // Your Gmail address
    'client_id'     => '564128713339-o9igjn46kimikahbbc92ki59uge0lf3t.apps.googleusercontent.com', // From Google Cloud
    'client_secret' => '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', // From Google Cloud
    'refresh_token' => '1//0eDg4KCfvHB1nCgYIARAAGA4SNwF-L9IrJpumvEktiNSWBhhXN0jV-StZrwwoMrJzOHPFF4_p82UtbXneC_0HP0QRLN2xKUJx_a8', // From get_oauth_token.php
    'from_name'     => 'gmailer' // Display name for emails
]);

// Enable error reporting for development (disable in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('UTC');
?>