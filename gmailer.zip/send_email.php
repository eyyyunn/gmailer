<?php
// Enable error reporting but don't display errors (log them instead)
ini_set('display_errors', 0);
ini_set('log_errors', 1);
error_reporting(E_ALL);

// Set CORS headers
header('Access-Control-Allow-Origin: http://localhost');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Function to send JSON response
function sendJsonResponse($success, $message, $errors = []) {
    $response = [
        'success' => $success,
        'message' => $message
    ];
    
    if (!empty($errors)) {
        $response['errors'] = $errors;
    }
    
    echo json_encode($response);
    exit;
}

try {
    // Only process POST requests
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        sendJsonResponse(false, 'Method not allowed');
    }

    // Check if required files exist
    if (!file_exists('config.php') || !file_exists('GmailOAuthMailer.php')) {
        error_log("Missing required files: config.php or GmailOAuthMailer.php");
        sendJsonResponse(false, 'Server configuration error');
    }

    require_once 'config.php';
    require_once 'GmailOAuthMailer.php';

    // Get and sanitize form data - FIXED DEPRECATED CONSTANTS
    $name = isset($_POST['name']) ? filter_var(trim($_POST['name']), FILTER_SANITIZE_FULL_SPECIAL_CHARS) : '';
    $email = isset($_POST['email']) ? filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL) : '';
    $subject = isset($_POST['subject']) ? filter_var(trim($_POST['subject']), FILTER_SANITIZE_FULL_SPECIAL_CHARS) : 'Website Inquiry';
    $message = isset($_POST['message']) ? filter_var(trim($_POST['message']), FILTER_SANITIZE_FULL_SPECIAL_CHARS) : '';

    // Validate input
    $errors = [];
    if (empty($name)) $errors[] = 'Name is required';
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email is required';
    if (empty($message)) $errors[] = 'Message is required';
    if (strlen($message) < 10) $errors[] = 'Message should be at least 10 characters long';

    if (!empty($errors)) {
        sendJsonResponse(false, 'Please fix the following errors:', $errors);
    }

    // Initialize mailer
    $mailer = new GmailOAuthMailer(GMAIL_OAUTH_CONFIG);
    
    // Create HTML email content
    $htmlBody = "
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; }
                .header { background: #f8f9fa; padding: 20px; text-align: center; }
                .content { padding: 25px; background: #ffffff; }
                .field { margin-bottom: 15px; padding: 10px; background: #f8f9fa; border-radius: 4px; }
                .field-label { font-weight: bold; color: #495057; }
            </style>
        </head>
        <body>
            <div class='header'>
                <h2>New Contact Form Submission</h2>
            </div>
            <div class='content'>
                <div class='field'><span class='field-label'>Name:</span> " . htmlspecialchars($name) . "</div>
                <div class='field'><span class='field-label'>Email:</span> " . htmlspecialchars($email) . "</div>
                <div class='field'><span class='field-label'>Subject:</span> " . htmlspecialchars($subject) . "</div>
                <div class='field'><span class='field-label'>Message:</span><br>" . nl2br(htmlspecialchars($message)) . "</div>
            </div>
        </body>
        </html>
    ";

    // Send email
    $recipientEmail = 'yboian577@gmail.com';
    $emailSubject = "Website Contact: $subject";
    
    $result = $mailer->sendEmail($recipientEmail, $emailSubject, $htmlBody, true);

    if ($result['success']) {
        sendJsonResponse(true, 'Thank you! Your message has been sent successfully.');
    } else {
        error_log("Mailer error: " . ($result['error'] ?? 'Unknown error'));
        sendJsonResponse(false, 'Sorry, there was an error sending your message. Please try again later.');
    }

} catch (Exception $e) {
    // Log the error but don't expose details to user
    error_log("Unexpected error in send_email.php: " . $e->getMessage());
    error_log("Stack trace: " . $e->getTraceAsString());
    
    sendJsonResponse(false, 'An unexpected error occurred. Please try again later.');
}
?>