<?php
echo '<h1>Current Server Configuration</h1>';
echo '<p><strong>HTTP Host:</strong> ' . ($_SERVER['HTTP_HOST'] ?? 'Not set') . '</p>';
echo '<p><strong>Server Name:</strong> ' . ($_SERVER['SERVER_NAME'] ?? 'Not set') . '</p>';
echo '<p><strong>Server Port:</strong> ' . ($_SERVER['SERVER_PORT'] ?? 'Not set') . '</p>';
echo '<p><strong>Request URI:</strong> ' . ($_SERVER['REQUEST_URI'] ?? 'Not set') . '</p>';
echo '<p><strong>Suggested redirect URI:</strong> http://' . $_SERVER['HTTP_HOST'] . '/gmailer/get_oauth_token.php</p>';

// Test if this matches what's in Google Cloud
echo '<div style="background: #d4edda; padding: 15px; margin: 20px 0;">';
echo '<h3>Add this to Google Cloud Console:</h3>';
echo '<code>http://' . $_SERVER['HTTP_HOST'] . '/gmailer/get_oauth_token.php</code>';
echo '</div>';
?>