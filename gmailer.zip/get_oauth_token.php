<?php
require 'vendor/autoload.php';

use League\OAuth2\Client\Provider\Google;

session_start();

$clientId = '564128713339-o9igjn46kimikahbbc92ki59uge0lf3t.apps.googleusercontent.com';
$clientSecret = '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';
$redirectUri = 'http://localhost/gmailer/get_oauth_token.php';

$provider = new Google([
    'clientId'     => $clientId,
    'clientSecret' => $clientSecret,
    'redirectUri'  => $redirectUri,
]);

// Force consent to get refresh token
$options = [
    'scope' => [
        'https://www.googleapis.com/auth/gmail.send',
        'https://www.googleapis.com/auth/gmail.compose'
    ],
    'access_type' => 'offline',
    'prompt' => 'consent' // ← THIS IS CRITICAL
];

if (!isset($_GET['code'])) {
    $authUrl = $provider->getAuthorizationUrl($options);
    $_SESSION['oauth2state'] = $provider->getState();
    header('Location: ' . $authUrl);
    exit;

} else {
    try {
        if (empty($_GET['state']) || ($_GET['state'] !== $_SESSION['oauth2state'])) {
            throw new Exception('Invalid state parameter');
        }

        $token = $provider->getAccessToken('authorization_code', [
            'code' => $_GET['code']
        ]);

        // DEBUG: Show all token data
        echo '<h1>Full Token Response</h1>';
        echo '<pre>';
        print_r($token);
        echo '</pre>';

        // Check if refresh token exists
        $refreshToken = $token->getRefreshToken();
        
        if (empty($refreshToken)) {
            echo '<div style="background: #fff3cd; padding: 20px; margin: 20px 0; border: 1px solid #ffeaa7;">
                    <h3>⚠️ No Refresh Token Received!</h3>
                    <p>Google did not provide a refresh token. This usually happens if you\'ve already authorized the app before.</p>
                    <p><strong>Solution:</strong> Revoke access and try again:</p>
                    <ol>
                        <li>Go to <a href="https://myaccount.google.com/permissions" target="_blank">Google Account Permissions</a></li>
                        <li>Find your app and click "Revoke Access"</li>
                        <li><a href="get_oauth_token.php">Try again</a></li>
                    </ol>
                  </div>';
        } else {
            echo '<div style="background: #d4edda; padding: 20px; margin: 20px 0;">
                    <h3>✅ Success! Refresh Token Received</h3>
                    <p><strong>Refresh Token:</strong> ' . $refreshToken . '</p>
                    <p>Save this in your config.php file</p>
                  </div>';
        }

        echo '<p><strong>Access Token:</strong> ' . $token->getToken() . '</p>';
        echo '<p><strong>Expires:</strong> ' . date('Y-m-d H:i:s', $token->getExpires()) . '</p>';

    } catch (Exception $e) {
        echo '<h1>Error</h1>';
        echo '<p>Error: ' . $e->getMessage() . '</p>';
    }
}
?>